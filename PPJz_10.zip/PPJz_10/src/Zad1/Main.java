package Zad1;

public class Main {

	public static void main(String[] args) {
		
		int wrt1 = 5;
		float wrt2 = 2.1f;
		char wrt3 = 'c';
		byte wrt4 = 2;
		
		ZbiorMetod.ustalWartosc(wrt1);
		ZbiorMetod.ustalWartosc(wrt2);
		ZbiorMetod.ustalWartosc(wrt3);
		ZbiorMetod.ustalWartosc(wrt4);

	}

}
