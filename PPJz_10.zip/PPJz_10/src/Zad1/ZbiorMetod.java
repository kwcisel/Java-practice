package Zad1;

public class ZbiorMetod {

	public static void ustalWartosc(int wrt){
		System.out.println("Typ = int, wartosc = " + wrt);
	}
	
	public static void ustalWartosc(float wrt){
		System.out.println("Typ = float, wartosc = " + wrt);
	}
	
}
