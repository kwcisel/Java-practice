package Zad2;

public class Liczba {

	public int wrt;
	
	public void przypiszWartosc(int wrt){
		this.wrt = wrt;
	}
	
	public void wyswietlWartosc(int wrt){
		System.out.println(wrt);
	}
	
}
